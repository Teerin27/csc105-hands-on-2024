import { NavLink } from 'react-router-dom';

const Navbar = () => {
  return (
    <nav className="bg-blue-600 p-4 shadow-lg">
      <ul className="flex justify-center space-x-8">
        <li>
          <NavLink
            to="/"
            className="text-white font-semibold text-lg hover:text-blue-200"
            end
          >
            Home
          </NavLink>
        </li>
        <li>
          <NavLink
            to="/login"
            className="text-white font-semibold text-lg hover:text-blue-200"
          >
            Login
          </NavLink>
        </li>
        <li>
          <NavLink
            to="/fav"
            className="text-white font-semibold text-lg hover:text-blue-200"
          >
            Favourites
          </NavLink>
        </li>
      </ul>
    </nav>
  );
};

export default Navbar;
