import { useParams, useSearchParams } from 'react-router-dom';

const FavouriteDetailPage = () => {
  const { id } = useParams();
  const [searchParams] = useSearchParams();
  const q = searchParams.get('q');
  const size = searchParams.get('size');

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center">
      <div className="bg-white p-8 rounded-lg shadow-lg max-w-md w-full">
        <h1 className="text-3xl font-bold text-center text-gray-800">Favourite Detail</h1>
        <p className="mt-4 text-xl text-gray-600">Your favourite post is <strong>{q}</strong>.</p>
        <p className="mt-2 text-lg text-gray-600">Post ID: <strong>{id}</strong></p>
        <p className="mt-2 text-lg text-gray-600">Size: <strong>{size}</strong></p>
        <img src="https://i.imgflip.com/9grj9y.png?a484080"></img>
      </div>
    </div>
  );
};

export default FavouriteDetailPage;
