import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useNavigate } from 'react-router-dom';

const favouritesSchema = z.object({
  number: z.number(z).min(0).max(100, { message: 'Number must be between 1 and 100' }),
  q: z.enum(['love', 'like']),
  size: z.enum(['small', 'medium', 'large'])
});

const FavouritesPage = () => {
  const navigate = useNavigate();
  const { register, handleSubmit, formState: { errors } } = useForm({
    resolver: zodResolver(favouritesSchema)
  });

  const onSubmit = (data) => {
    navigate(`/fav/${data.number}?q=${data.q}&size=${data.size}`);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <h1 className="text-4xl font-bold text-center text-gray-800 mt-10">Favourites Page</h1>
      <form onSubmit={handleSubmit(onSubmit)} className="mt-6 max-w-lg mx-auto space-y-6">
        <div>
          <label className="block text-gray-700">Number (1-100) </label>
          <input
            type="number"
            {...register('number')}
            className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          />

            {errors.number && <p className="text-red-500">{errors.number.message}</p>}  
        </div>
        <div>
          <label className="block text-gray-500">Query</label>
          <select
            {...register('q')}
            className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="love">Love</option>
            <option value="like">Like</option>
          </select>
          {errors.q && <p className="text-red-500">{errors.q.message}</p>}
        </div>
        <div>
          <label className="block text-gray-700">Size</label>
          <select
            {...register('size')}
            className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="small">Small</option>
            <option value="medium">Medium</option>
            <option value="large">Large</option>
          </select>
          {errors.size && <p className="text-red-500">{errors.size.message}</p>}
        </div>
        <button
          type="submit"
          className="w-full p-3 bg-blue-600 text-white rounded-lg hover:bg-blue-500 focus:outline-none"
        >
          Go to Favourite Details
        </button>
      </form>
    </div>
  );
};

export default FavouritesPage;
