//import Navbar from '../components/Navbar';

const HomePage = () => {
  return (
    <div className="min-h-screen bg-gray-50">
      
      <div className="text-center mt-16">
        <h1 className="text-4xl font-extrabold text-gray-800">Welcome to the Home Page</h1>
        <p className="mt-4 text-xl text-gray-600">Explore our site and enjoy the features!</p>
       
      </div>
    </div>
  );
};

export default HomePage;
