import { NavLink,Outlet } from 'react-router-dom';
import Navbar from './components/Navbar';

function App ()  {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navbar is always visible */}
      <Navbar />
      
      {/* Main content */}
      <div className="container mx-auto px-4 py-6">
        <Outlet />
      </div>
    </div>
  );
};

export default App;
